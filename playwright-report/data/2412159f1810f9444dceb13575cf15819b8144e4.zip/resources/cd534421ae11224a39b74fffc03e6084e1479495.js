(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@sanity_6f7f2dcc._.js",
  "static/chunks/_afdfbf13._.js",
  "static/chunks/node_modules_ec4a34ce._.js"
],
    source: "dynamic"
});
