(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@sanity/client/dist/_chunks-es/stegaEncodeSourceMap.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@sanity_client_dist__chunks-es_stegaEncodeSourceMap_770f8478.js",
  "static/chunks/node_modules_@sanity_client_dist__chunks-es_stegaEncodeSourceMap_0d4bf292.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@sanity/client/dist/_chunks-es/stegaEncodeSourceMap.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/@sanity/eventsource/browser.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_80fc8afc._.js",
  "static/chunks/node_modules_@sanity_eventsource_browser_0d4bf292.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@sanity/eventsource/browser.js [app-client] (ecmascript)");
    });
});
}),
]);