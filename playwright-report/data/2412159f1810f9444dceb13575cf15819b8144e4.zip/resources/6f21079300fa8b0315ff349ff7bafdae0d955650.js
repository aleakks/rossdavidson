(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__e153235a._.css",
  "static/chunks/node_modules_87bc9f79._.js",
  "static/chunks/components_ebf00071._.js"
],
    source: "dynamic"
});
